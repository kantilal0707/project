// Simple Node.js backend for Electro-Bootstrap
// Run: npm install express
// Start: node server.js

const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from Electro-Bootstrap
app.use(express.static(path.join(__dirname, '.')));

// Example API endpoint
app.get('/api/products', (req, res) => {
    // Example static data, replace with database logic as needed
    res.json([
        { id: 1, name: 'Product 1', price: 100 },
        { id: 2, name: 'Product 2', price: 200 }
    ]);
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
