// CRUD API for items with MongoDB (Node.js + Express)
// Run: npm install express mongoose
// Start: node items-api.js

const express = require('express');
const mongoose = require('mongoose');
const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/electro_bootstrap', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const itemSchema = new mongoose.Schema({
    name: String,
    price: Number,
    category: String
});

const cartSchema = new mongoose.Schema({
    userId: String, // For demo, use a string. In production, use ObjectId and authentication
    items: [
        {
            itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Item' },
            quantity: { type: Number, default: 1 }
        }
    ]
});

const Item = mongoose.model('Item', itemSchema);
const Cart = mongoose.model('Cart', cartSchema);
// Add item to cart
app.post('/api/cart/:userId/add', async (req, res) => {
    const { itemId, quantity } = req.body;
    let cart = await Cart.findOne({ userId: req.params.userId });
    if (!cart) {
        cart = new Cart({ userId: req.params.userId, items: [] });
    }
    const itemIndex = cart.items.findIndex(i => i.itemId.toString() === itemId);
    if (itemIndex > -1) {
        cart.items[itemIndex].quantity += quantity || 1;
    } else {
        cart.items.push({ itemId, quantity: quantity || 1 });
    }
    await cart.save();
    res.json(cart);
});

// Get cart for user
app.get('/api/cart/:userId', async (req, res) => {
    const cart = await Cart.findOne({ userId: req.params.userId }).populate('items.itemId');
    if (!cart) return res.json({ items: [] });
    res.json(cart);
});

// Update cart item quantity
app.put('/api/cart/:userId/update', async (req, res) => {
    const { itemId, quantity } = req.body;
    let cart = await Cart.findOne({ userId: req.params.userId });
    if (!cart) return res.status(404).json({ error: 'Cart not found' });
    const itemIndex = cart.items.findIndex(i => i.itemId.toString() === itemId);
    if (itemIndex > -1) {
        cart.items[itemIndex].quantity = quantity;
        await cart.save();
        res.json(cart);
    } else {
        res.status(404).json({ error: 'Item not in cart' });
    }
});

// Remove item from cart
app.delete('/api/cart/:userId/remove', async (req, res) => {
    const { itemId } = req.body;
    let cart = await Cart.findOne({ userId: req.params.userId });
    if (!cart) return res.status(404).json({ error: 'Cart not found' });
    cart.items = cart.items.filter(i => i.itemId.toString() !== itemId);
    await cart.save();
    res.json(cart);
});

// Get all items with optional filters
app.get('/api/items', async (req, res) => {
    const { price, category } = req.query;
    let filter = {};
    if (price) filter.price = { $lte: parseFloat(price) };
    if (category) filter.category = category;
    const items = await Item.find(filter);
    res.json(items);
});

// Get single item
app.get('/api/items/:id', async (req, res) => {
    const item = await Item.findById(req.params.id);
    if (!item) return res.status(404).json({ error: 'Item not found' });
    res.json(item);
});

// Create item
app.post('/api/items', async (req, res) => {
    const { name, price, category } = req.body;
    const newItem = new Item({ name, price, category });
    await newItem.save();
    res.status(201).json(newItem);
});

// Update item
app.put('/api/items/:id', async (req, res) => {
    const { name, price, category } = req.body;
    const item = await Item.findById(req.params.id);
    if (!item) return res.status(404).json({ error: 'Item not found' });
    if (name) item.name = name;
    if (price) item.price = price;
    if (category) item.category = category;
    await item.save();
    res.json(item);
});

// Delete item
app.delete('/api/items/:id', async (req, res) => {
    const item = await Item.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ error: 'Item not found' });
    res.json({ success: true });
});

app.listen(PORT, () => {
    console.log(`Items API with MongoDB running on http://localhost:${PORT}`);
});
